package com.cuoiky.nhom26.controller;





import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        return "homes/index"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/rooms")
    public String room() {
        return "homes/rooms"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/room-details")
    public String roomdetail() {
        return "homes/room-details"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/about")
    public String about() {
        return "homes/about"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/blog")
    public String blog() {
        return "homes/blog"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/blog-details")
    public String blogdetails() {
        return "homes/blog-details"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/contact")
    public String contact() {
        return "homes/contact"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
    @GetMapping("/main")
    public String main() {
        return "homes/main"; // Trả về tên của view (file index.html trong thư mục templates/homes)
    }
}
