package com.cuoiky.nhom26.model;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
public class Amenity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @ManyToMany(mappedBy = "amenities")
    private Set<Room> rooms = new HashSet<>();

    // Getters and setters
    // Constructor
    // toString method
}
