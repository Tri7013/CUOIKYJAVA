package com.cuoiky.nhom26.repository;

import com.cuoiky.nhom26.model.Amenity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AmenityRepository extends JpaRepository<Amenity, Long> {
}
