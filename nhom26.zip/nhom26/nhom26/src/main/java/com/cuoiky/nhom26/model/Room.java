package com.cuoiky.nhom26.model;

public class Room {
}
